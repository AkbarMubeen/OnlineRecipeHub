﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace RecipeHubApi.Model
{
    public class RecipeHub
    {
        [Key]
        [Required]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public Guid Id { get; set; }

        [Required(ErrorMessage = "Title is required")]
        [MaxLength(200)]
        public string Title { get; set; }

        [Required(ErrorMessage = "Level is required")]
        [MaxLength(10)]
        public string Level { get; set; }

        [Required(ErrorMessage = "Steps are required")]
        [MaxLength(400)]
        public string Steps { get; set; }

        [Required(ErrorMessage = "Ingredients are required")]
        [MaxLength(400)]
        public string  Ingrediants { get; set; }

        [Required]
        public DateTime CreatedDateTime { get; set; }

        public DateTime? ModifyDateTime { get; set; }
    }
}
