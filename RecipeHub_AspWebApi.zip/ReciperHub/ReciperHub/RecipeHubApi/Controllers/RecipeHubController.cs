﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using RecipeHubApi.Model;
using RecipeHubApi.Repository;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace RecipeHubApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RecipeHubController : ControllerBase
    {
        private readonly IRecipeHubRepository _recipeHubRepository;
        public RecipeHubController(IRecipeHubRepository recipeHubRepository)
        {
            _recipeHubRepository = recipeHubRepository;
        }
        // GET: api/<RecipeHubController>
        [HttpGet]
        public async Task <ActionResult<IEnumerable<RecipeHub>>> Get()
        {
            try
            {
                var result = await _recipeHubRepository.GetAllRecipies();
                return Ok(result.ToList());
            }
            catch (Exception)
            {

                return StatusCode(StatusCodes.Status500InternalServerError,
                         "An unexpected error has ocurred.");
            }
           
        }

        // GET api/<RecipeHubController>/5
        [HttpGet("{id}")]
        public async Task<ActionResult<RecipeHub>> Get(Guid id)
        {
            try
            {
                if (id == null || id == Guid.Empty)
                {
                    return BadRequest("id cannot be null or empty");
                }

                var result = await _recipeHubRepository.GetRecipeById(id);

                if (result == null)
                {

                    return BadRequest($"no recipe is found for given id {id}");
                }
                return Ok(result);
            }
            catch (Exception)
            {

                return StatusCode(StatusCodes.Status500InternalServerError,
                         "An unexpected error has ocurred.");
            }
            
            
        }

        // POST api/<RecipeHubController>
        [HttpPost]
        public async Task<ActionResult<RecipeHub>> Post(RecipeHub recipeHub)
        {
            try
            {
                if(recipeHub == null)
                {
                    return BadRequest("recipeHub object cannot be null or empty");
                }

                var result = await _recipeHubRepository.AddRecipe(recipeHub);

                return Ok(result);
            }
            catch (Exception)
            {

                return StatusCode(StatusCodes.Status500InternalServerError,
                         "An unexpected error has ocurred.");
            }
        }

        // PUT api/<RecipeHubController>/5
        [HttpPut("{id}")]
        public async Task<ActionResult<RecipeHub>> Put(Guid id, RecipeHub recipeHub)
        {
            try
            {
                if(id == null || id == Guid.Empty)
                {
                    return BadRequest("id cannot be null empty.");
                }
                if(recipeHub == null)
                {
                    return BadRequest("recipeHub object cannot be null or empty");
                }

                var result = await _recipeHubRepository.UpdateRecipe(id, recipeHub);

                if(result == null)
                {
                    return BadRequest($"no recipe is found to update for given id {id}");
                }

                return Ok(result);
            }
            catch (Exception)
            {

                return StatusCode(StatusCodes.Status500InternalServerError,
                       "An unexpected error has ocurred.");
            }
        }

        // DELETE api/<RecipeHubController>/5
        [HttpDelete("{id}")]
        public async Task <ActionResult<bool>> Delete(Guid id)
        {
            try
            {
                if(id == null || id == Guid.Empty)
                {
                    return BadRequest("id cannot be null or emtpy");
                }

                var isDeleted = await _recipeHubRepository.DeleteRecipeById(id);
                if (!isDeleted)
                {
                    return BadRequest($"no recipe is found to delete for given id{id}");
                }

                return Ok(true);
            }
            catch (Exception)
            {

                return StatusCode(StatusCodes.Status500InternalServerError,
                     "An unexpected error has ocurred.");
            }
        }
    }
}
;