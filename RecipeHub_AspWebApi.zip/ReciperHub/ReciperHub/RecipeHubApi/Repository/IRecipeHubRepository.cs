﻿using RecipeHubApi.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RecipeHubApi.Repository
{
    public interface IRecipeHubRepository
    {
        Task<RecipeHub> AddRecipe(RecipeHub recipeHub);
        Task<IEnumerable<RecipeHub>> GetAllRecipies();
        Task<RecipeHub> GetRecipeById(Guid id);
        Task<RecipeHub> UpdateRecipe(Guid id, RecipeHub recipeHub);
        Task<bool> DeleteRecipeById(Guid id);
    }
}
