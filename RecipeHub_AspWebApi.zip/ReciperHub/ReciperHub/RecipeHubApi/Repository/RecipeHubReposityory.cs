﻿using Microsoft.EntityFrameworkCore;
using RecipeHubApi.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;

namespace RecipeHubApi.Repository
{
    public class RecipeHubReposityory : IRecipeHubRepository
    {
        private readonly AppDbContext _appDbContext;
        public RecipeHubReposityory(AppDbContext appDbContext)
        {
            _appDbContext = appDbContext;
        }
        public async Task<RecipeHub> AddRecipe(RecipeHub recipeHub)
        {
            recipeHub.Id = Guid.NewGuid();
            recipeHub.CreatedDateTime = DateTime.Now;

            var result = await _appDbContext.RecipeHubs.AddAsync(recipeHub);
            _appDbContext.SaveChanges();

            return result.Entity;
        }

        public async Task<bool> DeleteRecipeById(Guid id)
        {
            var recipeObj = _appDbContext.RecipeHubs.FirstOrDefaultAsync(u => u.Id == id);
            //if (recipeObj == null) return false;

            _appDbContext.Remove(recipeObj);
            await _appDbContext.SaveChangesAsync();

            return true;
        }

        public async Task<IEnumerable<RecipeHub>> GetAllRecipies()
        {
            return await _appDbContext.RecipeHubs.ToListAsync();
        }

        public async Task<RecipeHub> GetRecipeById(Guid id)
        {
            
            return await _appDbContext.RecipeHubs.FirstOrDefaultAsync(u => u.Id == id);
        }

        public async Task<RecipeHub> UpdateRecipe(Guid id, RecipeHub recipeHub)
        {
            var objRecipe = await _appDbContext.RecipeHubs.FirstOrDefaultAsync(u => u.Id == id);


            if (objRecipe == null)
            {
                return null;
            }

            objRecipe.Title = recipeHub.Title;
            objRecipe.Level = recipeHub.Level;
            objRecipe.Steps = recipeHub.Steps;
            objRecipe.Ingrediants = recipeHub.Ingrediants;
            objRecipe.ModifyDateTime = DateTime.Now;

            var update = _appDbContext.RecipeHubs.Attach(objRecipe);
            update.State = EntityState.Modified;
            _appDbContext.SaveChanges();

            return objRecipe;


        }
    }
}
